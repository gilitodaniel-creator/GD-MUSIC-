const { initializeTestEnvironment, assertFails, assertSucceeds } = require('@firebase/rules-unit-testing');
const fs = require('fs');
const test = require('node:test');

const PROJECT_ID = 'demo-no-project';
const DATABASE_ID = 'ai-studio-android-mixeprod-2f229e38-1dd1-4b9a-a6c0-f59a63e0b021';

test('Firestore Security Rules Testing', async (t) => {
  let testEnv;

  t.before(async () => {
    testEnv = await initializeTestEnvironment({
      projectId: PROJECT_ID,
      firestore: {
        host: '127.0.0.1',
        port: 8085,
        rules: fs.readFileSync('firestore.rules', 'utf8')
      }
    });
  });

  t.after(async () => {
    if (testEnv) {
      await testEnv.cleanup();
    }
  });

  t.beforeEach(async () => {
    if (testEnv) {
      await testEnv.clearFirestore();
    }
  });

  await t.test('Unauthenticated users cannot read or write published songs', async () => {
    const unauthedDb = testEnv.unauthenticatedContext().firestore({ databaseId: DATABASE_ID });
    const songsRef = unauthedDb.collection('published_songs');
    await assertFails(songsRef.get());
    await assertFails(songsRef.doc('song_123').set({
      id: 'song_123',
      title: 'Son de Prueba',
      artist: 'Banda Filarmónica',
      community: 'Ayutla',
      genre: 'Son y Jarabe',
      melodyType: 'JARABE_MIXE',
      durationSec: 180,
      culturalNotes: 'Notas',
      publisherUid: 'fake_uid',
      createdAt: new Date(),
      updatedAt: new Date()
    }));
  });

  await t.test('Authenticated producer can publish valid song', async () => {
    const authDb = testEnv.authenticatedContext('producer_uid', { email: 'gilito.daniel@gmail.com' }).firestore({ databaseId: DATABASE_ID });
    const songDoc = authDb.collection('published_songs').doc('song_ayutla_2026');
    await assertSucceeds(songDoc.set({
      id: 'song_ayutla_2026',
      title: 'Jarabe de la Cumbre',
      ayuukTitle: 'Ayuuk Jä’äy',
      artist: 'Banda Municipal de Ayutla',
      community: 'Ayutla Mixe',
      genre: 'Son y Jarabe',
      melodyType: 'JARABE_MIXE',
      durationSec: 210,
      culturalNotes: 'Grabación comunitaria en atrio',
      publisherUid: 'producer_uid',
      publisherName: 'Gilito Daniel',
      publisherEmail: 'gilito.daniel@gmail.com',
      createdAt: new Date(),
      updatedAt: new Date()
    }));
  });

  await t.test('Another user cannot modify published song by different producer', async () => {
    const producerDb = testEnv.authenticatedContext('producer_uid').firestore({ databaseId: DATABASE_ID });
    const songDoc = producerDb.collection('published_songs').doc('song_protected');
    await assertSucceeds(songDoc.set({
      id: 'song_protected',
      title: 'Cumbia del Cerro',
      artist: 'Banda Tierra Mixe',
      community: 'Tamazulápam',
      genre: 'Cumbia Mixe',
      melodyType: 'CUMBIA_TROPICAL',
      durationSec: 190,
      culturalNotes: 'Baile popular',
      publisherUid: 'producer_uid',
      createdAt: new Date(),
      updatedAt: new Date()
    }));

    const hackerDb = testEnv.authenticatedContext('hacker_uid').firestore({ databaseId: DATABASE_ID });
    await assertFails(hackerDb.collection('published_songs').doc('song_protected').update({
      title: 'Hacked Song'
    }));
    await assertFails(hackerDb.collection('published_songs').doc('song_protected').delete());
  });

  await t.test('Users cannot access other user private profile', async () => {
    const userDb = testEnv.authenticatedContext('user_1').firestore({ databaseId: DATABASE_ID });
    await assertSucceeds(userDb.collection('users').doc('user_1').set({
      userId: 'user_1',
      displayName: 'Gilito',
      email: 'gilito.daniel@gmail.com',
      role: 'producer',
      createdAt: new Date(),
      updatedAt: new Date()
    }));

    const otherDb = testEnv.authenticatedContext('user_2').firestore({ databaseId: DATABASE_ID });
    await assertFails(otherDb.collection('users').doc('user_1').get());
  });
});
